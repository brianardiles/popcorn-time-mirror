module.exports = require(__dirname + "/WebChimera.js.node");
